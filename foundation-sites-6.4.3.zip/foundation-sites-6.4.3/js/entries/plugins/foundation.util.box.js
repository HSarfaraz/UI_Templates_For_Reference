import { Foundation } from './foundation.core';
import { Box } from '../../foundation.util.box';

Foundation.Box = Box;
