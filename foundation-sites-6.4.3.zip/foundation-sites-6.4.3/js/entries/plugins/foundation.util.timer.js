import { Foundation } from './foundation.core';

import { Timer } from '../../foundation.util.timer';

Foundation.Timer = Timer;
