import { Foundation } from './foundation.core';

import { Slider } from '../../foundation.slider';
Foundation.plugin(Slider, 'Slider');

