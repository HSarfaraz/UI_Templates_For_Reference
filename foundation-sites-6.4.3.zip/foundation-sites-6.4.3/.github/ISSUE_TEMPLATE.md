<!-- For replicatable bugs or feature requests GitHub is the right place. The [Foundation Forum](http://foundation.zurb.com/forum) would be a great place to seek some help with general questions or help with your code. There you can reach out to the community to share your insights or ask questions. -->

#### How to reproduce this bug:

1. Step one
2. Step two
3. Step three

#### What should happen:

#### What happened instead:

#### Browser(s) and Device(s) tested on:

#### Foundation Version(s) you are using:

#### Test case link:

<!-- Give us a link to a CodePen or JSFiddle that recreates the issue. -->

- [CodePen with Foundation 6.3.1, Float Grid and MotionUI](http://codepen.io/IamManchanda/pen/LWGZxR)
- [CodePen with Foundation 6.3.1, Float Grid with RTL Direction and MotionUI](http://codepen.io/IamManchanda/pen/bRYOMv)
- [CodePen with Foundation 6.3.1, Flexbox grid and MotionUI](http://codepen.io/IamManchanda/pen/zZrBEv)

- [CodePen with Foundation 6.4.1, XY Flexbox grid and MotionUI](http://codepen.io/IamManchanda/pen/EXbGKJ)
- [CodePen with Foundation 6.4.1, XY Flexbox grid with RTL Direction and MotionUI](http://codepen.io/IamManchanda/pen/qjVLoO)
- [CodePen with Foundation 6.4.1, XY Flexbox grid with Prototype Mode and MotionUI](http://codepen.io/IamManchanda/pen/XgzopG)
- [CodePen with Foundation 6.4.1, Float Grid and MotionUI](http://codepen.io/IamManchanda/pen/qjVLrB)
