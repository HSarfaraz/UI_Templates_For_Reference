
 # Documentation template

Free Bootstrap 4 documentation template.Author [sharebootstrap](https://sharebootstrap.com)


## Demo

[See it live](https://sharebootstrap.com/free-bootstrap-documentation-theme/)


## Quick start

```
npm install 

npm start
```

 Server runs on http://localhost:3000

## Resources
*   [Bootstrap](https://getbootstrap.com/)
*   [JQuery](http://jquery.com/)
*   [Font awsome](http://fontawesome.io/)
*   [Malihu custom scrollbar plugin](https://github.com/malihu/malihu-custom-scrollbar-plugin)

## License
This code is released under the license.

